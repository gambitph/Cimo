<?php
/**
 * Enqueue scripts for the admin area.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Cimo_Script_Loader' ) ) {
	class Cimo_Script_Loader {
		public function __construct() {
			// Enqueue for the block editor.
			add_action( 'enqueue_block_editor_assets', [ __CLASS__, 'enqueue_cimo_assets' ] );
			// Enqueue for Elementor.
			add_action( 'elementor/editor/before_enqueue_scripts', [ __CLASS__, 'enqueue_cimo_assets' ] );
			// Enqueue for Beaver Builder main window (outside BB's iframe).
			if ( class_exists( 'FLBuilderModel' ) ) {
				add_action( 'wp_head', [ $this, 'maybe_enqueue_for_beaver_builder' ], 999 );
			}
			// Enqueue for Bricks Builder
			add_action( 'bricks_before_site_wrapper', [ $this, 'maybe_enqueue_for_bricks_builder' ] );
			// Enqueue for Oxygen Builder
			add_action( 'oxygen_enqueue_ui_scripts', [ __CLASS__, 'enqueue_cimo_assets' ] );
			// Enqueue for Divi
			add_action( 'et_fb_enqueue_assets', [ __CLASS__, 'enqueue_cimo_assets' ] );
			// Enqueue for the admin area in general.
			add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_cimo_assets' ] );
		}

		/**
		 * Enqueue scripts in the main window when Beaver Builder is active.
		 */
		public function maybe_enqueue_for_beaver_builder() {
			// Check if we're in the Beaver Builder editor context.
			if ( class_exists( 'FLBuilderModel' ) && FLBuilderModel::is_builder_active() ) {
				self::enqueue_cimo_assets();
			}
		}

		/**
		 * Enqueue for Bricks Builder, but only when the builder is active.
		 */
		public function maybe_enqueue_for_bricks_builder() {
			if ( function_exists( 'bricks_is_builder' ) && bricks_is_builder() ) {
				self::enqueue_cimo_assets();
			}
		}

		/**
		 * Get selectors where Cimo should intercept file input selections.
		 *
		 * @return array
		 */
		public static function get_select_files_allowed_locations() {
			$locations = [
				'.components-form-file-upload', // Allow uploads to the image block.
				'.media-frame', // Allow uploads from the Media Manager.
				'.media-upload-form', // Allow uploads from the admin Media > Add Media File.
				'.moxie-shim', // Allow uploads from the admin Media > Library grid view.
			];

			// Public integration point for plugins/themes that want Cimo to auto-intercept
			// file inputs inside their own upload UI.
			return self::sanitize_allowed_locations(
				apply_filters( 'cimo/select_files/allowed_locations', $locations )
			);
		}

		/**
		 * Get selectors where Cimo should intercept file drops.
		 *
		 * @return array
		 */
		public static function get_drop_zone_allowed_locations() {
			$locations = [
				'.media-frame-uploader', // Allowed to drop in the Media Manager.
				'.media-upload-form', // Allowed to drop in the admin Media > Add Media File.
				'.editor-post-featured-image', // Allowed to drop in the featured image drop zone.
				'.editor-styles-wrapper', // Allowed to drop in the block editor when adding new image blocks.
				'.uploader-window', // Allowed to drop in the admin Media > Library grid view.
				'.uploader-editor', // Allowed to drop in the WooCommerce description editor.
				'.block-library-utils__media-control', // Allowed to drop in the block editor image block media control.
			];

			// Public integration point for plugins/themes that want Cimo to auto-intercept
			// dropped files inside their own upload UI.
			return self::sanitize_allowed_locations(
				apply_filters( 'cimo/drop_zone/allowed_locations', $locations )
			);
		}

		/**
		 * Keep localized selector settings as a clean list of strings.
		 *
		 * @param mixed $locations Selectors from defaults and filters.
		 * @return array
		 */
		private static function sanitize_allowed_locations( $locations ) {
			if ( ! is_array( $locations ) ) {
				return [];
			}

			$locations = array_filter( $locations, 'is_string' );
			$locations = array_map( 'trim', $locations );
			$locations = array_filter( $locations );

			return array_values( array_unique( $locations ) );
		}

		public static function enqueue_cimo_assets() {
			// If cimo-script is already enqueued, don't enqueue again.
			if ( wp_script_is( 'cimo-script', 'enqueued' ) ) {
				return;
			}

			// This should return the dependencies for both css and js, these will be merged with the default dependencies.
			$dependencies = apply_filters( 'cimo/script_loader/enqueue_cimo_assets', ['css' => [], 'js' => []] );

			$build_dir = plugin_dir_path( CIMO_FILE ) . 'build/admin/';
			$build_url = plugin_dir_url( CIMO_FILE ) . 'build/admin/';

			// Enqueue the main admin JavaScript file
			$script_asset = include $build_dir . 'index.asset.php';
			wp_enqueue_script(
				'cimo-script',
				$build_url . 'index.js',
				array_merge(
					// Remove wp-dom-ready since it's not really a dependency, but wp-scripts includes it.
					array_values( array_diff( $script_asset['dependencies'], [ 'wp-dom-ready' ] ) ),
					$dependencies['js']
				),
				$script_asset['version'],
				true
			);

			// Get current settings
			$settings = get_option( 'cimo_options', [] );

			// Expose threshold for WP Core's big image scaling.
			// Can be false when auto scaling is disabled.
			$threshold = apply_filters( 'big_image_size_threshold', 2560, array( 0, 0 ), '', 0 );

			// Localize script with REST API URL, nonce, and settings
			wp_localize_script(
				'cimo-script',
				'cimoSettings',
				[
					'restUrl' => rest_url( 'cimo/v1/' ),
					'settingsUrl' => admin_url( 'options-general.php?page=' . CIMO_SETTINGS_SLUG . '#cimo-stats' ),
					'nonce'   => wp_create_nonce( 'wp_rest' ),
					'isFrontend' => ! is_admin(),
					'isLoggedIn' => is_user_logged_in(),
					'canManageOptions' => current_user_can( 'manage_options' ),
					'optimizeAllMedia' => isset( $settings['optimize_all_media'] ) ? (int) $settings['optimize_all_media'] : 0,
					'isPremium' => CIMO_BUILD === 'premium',
					'optimizeAllMedia' => isset( $settings['optimize_all_media'] ) ? (int) $settings['optimize_all_media'] : 0,
					'showOptimizationToggle' => isset( $settings['show_optimization_toggle'] ) ? (int) $settings['show_optimization_toggle'] : 0,
					'showOptimizationToggleFrontend' => isset( $settings['show_optimization_toggle_frontend'] ) ? (int) $settings['show_optimization_toggle_frontend'] : 0,
					'persistOptimizationToggle' => isset( $settings['persist_optimization_toggle'] ) ? (int) $settings['persist_optimization_toggle'] : 0,
					'smartOptimization' => CIMO_BUILD === 'premium'
						? ( isset( $settings['smart_optimization'] ) ? (int) $settings['smart_optimization'] : 1 )
						: 0,
					'skipWebpOptimization' => isset( $settings['skip_webp_optimization'] ) ? (int) $settings['skip_webp_optimization'] : 0,
					'webpQuality' => ! empty( $settings['webp_quality'] ) ? (int) $settings['webp_quality'] : 80,
					'maxImageDimension' => ! empty( $settings['max_image_dimension'] ) ? (int) $settings['max_image_dimension'] : 0,
					'videoOptimizationEnabled' => isset( $settings['video_optimization_enabled'] ) ? (int) $settings['video_optimization_enabled'] : 1,
					'videoQuality' => ! empty( $settings['video_quality'] ) ? (int) $settings['video_quality'] : 3,
					'videoMaxResolution' => ! empty( $settings['video_max_resolution'] ) ? $settings['video_max_resolution'] : '',
					'audioOptimizationEnabled' => isset( $settings['audio_optimization_enabled'] ) ? (int) $settings['audio_optimization_enabled'] : 1,
					'audioQuality' => ! empty( $settings['audio_quality'] ) ? (int) $settings['audio_quality'] : 128,
					'svgUpload' => isset( $settings['svg_upload'] ) ? (int) $settings['svg_upload'] : 0,
					'svgOptimizationEnabled' => isset( $settings['svg_optimization_enabled'] ) ? (int) $settings['svg_optimization_enabled'] : 1,
					'stealthModeEnabled' => isset( $settings['stealth_mode_enabled'] ) ? (int) $settings['stealth_mode_enabled'] : 0,
					'wpScalingThreshold' => $threshold,
					// Public PHP selector filters are localized for the browser-side interceptors.
					'selectFilesAllowedLocations' => self::get_select_files_allowed_locations(),
					'dropZoneAllowedLocations' => self::get_drop_zone_allowed_locations(),
				]
			);

			// Enqueue the main admin CSS file
			$style_asset = include $build_dir . 'index-styles.asset.php';
			wp_enqueue_style(
				'cimo-script-styles',
				$build_url . 'index-styles.css',
				array_merge( $style_asset['dependencies'], $dependencies['css'] ),
				$style_asset['version']
			);
		}
	}

	new Cimo_Script_Loader();
}
